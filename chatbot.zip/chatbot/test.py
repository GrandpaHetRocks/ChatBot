from fuzzywuzzy import fuzz

def ch(query):
    dat1=[]
    dat2=[]
    dat3=[]
    dat4=[]
    for i in dataset1:
        ra=fuzz.token_set_ratio(query,i)
        dat1.append(ra)
    for i in dataset2:
        ra=fuzz.token_set_ratio(query,i)
        dat2.append(ra)
    for i in dataset3:
        ra=fuzz.token_set_ratio(query,i)
        dat3.append(ra)
    for i in dataset4:
        ra=fuzz.token_set_ratio(query,i)
        dat4.append(ra)
    print(dat1,dat2,dat3,dat4)

dataset1=['Hi !','How are you ?','Wassup ?','How you doin ?','What is your name ?','Hi','Wassup','how you doin','how are you','hello',1]
answerset1=['Hello! My name is LegoBot! How\'s your day?']

dataset2=['Im doing good !','Glad to meet you',2]
answerset2=['Im happy!']

dataset3=['Whats the weather like?',3]

dataset4=["translate this for me","translate",4]
answerset4=['Ok enter sentence']

ch(input())