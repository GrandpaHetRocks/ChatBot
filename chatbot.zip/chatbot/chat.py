import selenium
from selenium import webdriver
import datetime
import win32clipboard
import calc2
import googletrans
from googletrans import Translator
from fuzzywuzzy import fuzz


def ch(query):
    majordat=[]
    dat0=[]
    dat1=[]
    dat2=[]
    dat3=[]
    dat4=[]
    dat5=[]
    dat6=[]
    dat7=[]
    dat8=[]
    dat9=[]
    dat10=[]
    dat11=[]
    dat12=[]
    for i in dataset1:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat0.append(ra)
    majordat.append(max(dat0))
    for i in dataset2:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat1.append(ra)
    majordat.append(max(dat1))
    for i in dataset3:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat2.append(ra)
    majordat.append(max(dat2))
    for i in dataset4:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat3.append(ra)
    majordat.append(max(dat3))
    for i in dataset5:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat4.append(ra)
    majordat.append(max(dat4))
    for i in dataset6:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat5.append(ra)
    majordat.append(max(dat5))
    for i in dataset7:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat6.append(ra)
    majordat.append(max(dat6))
    for i in dataset8:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat7.append(ra)
    majordat.append(max(dat7))
    for i in dataset9:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat8.append(ra)
    majordat.append(max(dat8))
    for i in dataset10:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat9.append(ra)
    majordat.append(max(dat9))
    for i in dataset11:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat10.append(ra)
    majordat.append(max(dat10))
    for i in dataset12:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat11.append(ra)
    majordat.append(max(dat11))
    for i in dataset13:
        ra=fuzz.token_set_ratio(query.upper(),i.upper())
        dat12.append(ra)
    majordat.append(max(dat12))
    #print(majordat)
    if(max(majordat)>90):
        return(majordat.index(max(majordat)))
    else:
        return(100)

    
    

translator = Translator()

dataset1=['Hi !','How are you ?','Wassup ?','How you doin ?','What is your name ?','Hi','Wassup','how you doin','how are you','hello']
answerset1=['Hello! My name is LegoBot! How\'s your day?']

dataset2=['Im doing good !','Glad to meet you']
answerset2=['Im happy!']

dataset3=['Whats the weather like?',"weather"]

dataset4=["translate this for me","translate","can you translate"]
answerset4=['Ok enter sentence']

dataset5=["take a note","note","can you note this ?"]

dataset6=["What is the time ?","Whats the time?"]

dataset7=["Im hungry","Search for restaurants"]

dataset8=["Calculate this","Calculate","Calculator"]

dataset9=["Play this song"]

dataset10=["thanks","thank you"]

dataset11=["Bye","Goodbye","Adios","Good Night","Goodnight","Nyt","Quit"]

dataset12=["You're the best","You are da best","You are the best"]

dataset13=["Im sick","I am sick","Hospital"]


run=True
driver = webdriver.Chrome()


while(run):
    query=input("You: ")
    print("LegoBot: ",end="")
    num=ch(query)
    if(num!=100):
        if(num==0):
            print(answerset1[0])
        elif(num==1):
            print(answerset2[0])
        elif(num==2):
            loc1=""
            loc=input("Enter Location: ")
            driver.get("https://www.weather-forecast.com/")
            id_box = driver.find_element_by_id('location')
            id_box.send_keys(loc)
            searchb = driver.find_element_by_id('searchbtn')
            searchb.click()
            print("I have opened all reports in Chrome!")
        elif(num==3):
            run1=True
            print("Okay! Just enter the sentence or enter Quit!")
            while(run1):
                query2=input()
                if(query2=="Quit"):
                    run1=False
                    break
                else:
                    translated = translator.translate(query2)
                    print(translated.text)
        elif(num==5):
            print(datetime.datetime.now())
        elif(num==4):
            dateTimeObj = datetime.datetime.now()
            text=input("Enter the text ")
            f= open("notes.txt","a+")
            timestampStr = dateTimeObj.strftime("%d-%b-%Y (%H:%M:%S.%f)")
            f.write("\n")
            f.write(timestampStr)
            f.write("\n")
            f.write(text)
            f.close
        elif(num==7):
            print("I've opened the calculator")
            calc2.cal()
        elif(num==9):
            print("My Pleasure!")
        elif(num==10):
            print("Bye!!!")
            run=False
        elif(num==6):
            print("Searching for restaurants nearby: ")
            driver.get("https://www.google.com/maps")
            id_box = driver.find_element_by_id('searchboxinput')
            id_box.send_keys("restaurants near me")
            searchbtn=driver.find_element_by_id('searchbox-searchbutton')
            searchbtn.click()
            print("Results on Chrome, I'm famished too")
        elif(num==12):
            print("Searching for Hospitals nearby: ")
            driver.get("https://www.google.com/maps")
            id_box = driver.find_element_by_id('searchboxinput')
            id_box.send_keys("hospitals near me")
            searchbtn=driver.find_element_by_id('searchbox-searchbutton')
            searchbtn.click()
            print("Results on Chrome, Get Well Soon :)")
        elif(num==8):
            mus=input("Enter song: ")
            driver.get("https://www.youtube.com/")
            id_box = driver.find_element_by_name('search_query')
            id_box.send_keys(mus)
            searchbtn=driver.find_element_by_id('search-button')
            searchbtn.click()
            so= driver.find_element_by_id('img')
            so.click()
        elif(num==11):
            print("No, you know who is da best!!!")

    


    else:
        print("Here's Web Results for you")
        search_string=query
        search_string = search_string.replace(' ', '+')
        for i in range(1): 
            matched_elements = driver.get("https://www.google.com/search?q=" +
                                     search_string + "&start=" + str(i)) 