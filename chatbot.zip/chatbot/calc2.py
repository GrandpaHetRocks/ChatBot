from tkinter import *
import math
def cal():
    val=""
    def exp(num):
        global val
        global equ
        val=val+str(num)
        equ.set(val)
    def eq():
        global val
        global equ
        tot=str(eval(val))
        equ.set(tot) 

    def clear():
        global val
        global equ
        val=""
        equ.set("")
    def delete():
        global val
        global equ
        l=len(val)
        val=val[0:len(val)-1]
        equ.set(val)
    def trig(fn):
        global equ
        if(fn=="sin"):
            equ.set(math.sin(math.radians(float(val))))
        elif(fn=="cos"):
            equ.set(math.cos(math.radians(float(val))))
        elif(fn=="tan"):
            equ.set(math.tan(math.radians(float(val))))
        elif(fn=="atan"):
            equ.set(math.degrees((math.atan(float(val)))))
        elif(fn=="acos"):
            equ.set(math.degrees((math.acos(float(val)))))
        elif(fn=="asin"):
            equ.set(math.degrees((math.asin(float(val)))))
        elif(fn=="log10"):
            equ.set(math.log10(float(val)))   
        elif(fn=="sq"):
            equ.set(math.sqrt(float(val)))       
                    

    tk=Tk() 
    equ = StringVar() 
    win = Entry(tk, textvariable=equ).grid(row=7,column=5)

    bt1 =Button(tk, text=' 1 ', fg='black', bg='gray', 
                        command=lambda: exp(1), height=1, width=7) 
    bt1.grid(row=2, column=0) 
    
    bt2 =Button(tk, text=' 2 ', fg='black', bg='gray', 
                        command=lambda: exp(2), height=1, width=7) 
    bt2.grid(row=2, column=1) 
    
    bt3 =Button(tk, text=' 3 ', fg='black', bg='gray', 
                        command=lambda: exp(3), height=1, width=7) 
    bt3.grid(row=2, column=2) 
    
    bt4 =Button(tk, text=' 4 ', fg='black', bg='gray', 
                        command=lambda: exp(4), height=1, width=7) 
    bt4.grid(row=3, column=0) 
    
    bt5 =Button(tk, text=' 5 ', fg='black', bg='gray', 
                        command=lambda: exp(5), height=1, width=7) 
    bt5.grid(row=3, column=1) 
    
    bt6 =Button(tk, text=' 6 ', fg='black', bg='gray', 
                        command=lambda: exp(6), height=1, width=7) 
    bt6.grid(row=3, column=2) 
    
    bt7 =Button(tk, text=' 7 ', fg='black', bg='gray', 
                        command=lambda: exp(7), height=1, width=7) 
    bt7.grid(row=4, column=0) 
    
    bt8 =Button(tk, text=' 8 ', fg='black', bg='gray', 
                        command=lambda: exp(8), height=1, width=7) 
    bt8.grid(row=4, column=1) 
    
    bt9 =Button(tk, text=' 9 ', fg='black', bg='gray', 
                        command=lambda: exp(9), height=1, width=7) 
    bt9.grid(row=4, column=2) 
    
    bt0 =Button(tk, text=' 0 ', fg='black', bg='gray', 
                        command=lambda: exp(0), height=1, width=7) 
    bt0.grid(row=5, column=0)

    btdot =Button(tk, text=' . ', fg='black', bg='gray', 
                        command=lambda: exp("."), height=1, width=7) 
    btdot.grid(row=6, column=0) 
    
    plus =Button(tk, text=' + ', fg='black', bg='gray', 
                    command=lambda: exp("+"), height=1, width=7) 
    plus.grid(row=2, column=3) 
    
    miexps =Button(tk, text=' - ', fg='black', bg='gray', 
                    command=lambda: exp("-"), height=1, width=7) 
    miexps.grid(row=3, column=3) 
    
    multiply =Button(tk, text=' * ', fg='black', bg='gray', 
                        command=lambda: exp("*"), height=1, width=7) 
    multiply.grid(row=4, column=3) 
    
    divide =Button(tk, text=' / ', fg='black', bg='gray', 
                        command=lambda: exp("/"), height=1, width=7) 
    divide.grid(row=5, column=3) 
    
    equal =Button(tk, text=' = ', fg='black', bg='gray', 
                    command=eq, height=1, width=7) 
    equal.grid(row=5, column=2) 
    
    clear =Button(tk, text='Clear', fg='black', bg='gray', 
                    command=clear, height=1, width=7) 
    clear.grid(row=5, column='1')
    dele=Button(tk, text='Delete', fg='black', bg='gray', 
                    command=delete, height=1, width=7).grid(row=6, column=1)  
    br1=Button(tk, text='(', fg='black', bg='gray', 
                    command=lambda:exp("("), height=1, width=7).grid(row=6, column=2)
    br2=Button(tk, text=')', fg='black', bg='gray', 
                    command=lambda:exp(")"), height=1, width=7).grid(row=6, column=3)  
    sq=Button(tk, text='root', fg='black', bg='gray', 
                    command=lambda:trig("sq"), height=1, width=7).grid(row=7, column=0)
    power=Button(tk, text='power', fg='black', bg='gray', 
                    command=lambda:exp("pow("), height=1, width=7).grid(row=7, column=1)
    com=Button(tk, text=',', fg='black', bg='gray', 
                    command=lambda:exp(","), height=1, width=7).grid(row=7, column=2)   
    loga=Button(tk, text='log', fg='black', bg='gray', 
                    command=lambda:trig("log10"), height=1, width=7).grid(row=7, column=3)
    sin=Button(tk, text='sin', fg='black', bg='gray', 
                    command=lambda:trig("sin"), height=1, width=7).grid(row=8, column=1)
    cos=Button(tk, text='cos', fg='black', bg='gray', 
                    command=lambda:trig("cos"), height=1, width=7).grid(row=8, column=2)
    tan=Button(tk, text='tan', fg='black', bg='gray', 
                    command=lambda:trig("tan"), height=1, width=7).grid(row=8, column=3)
    atan=Button(tk, text='atan', fg='black', bg='gray', 
                    command=lambda:trig("atan"), height=1, width=7).grid(row=9, column=0)
    asin=Button(tk, text='asin', fg='black', bg='gray', 
                    command=lambda:trig("asin"), height=1, width=7).grid(row=9, column=1)
    acos=Button(tk, text='acos', fg='black', bg='gray', 
                    command=lambda:trig("acos"), height=1, width=7).grid(row=9, column=2)                     
    tk.mainloop()